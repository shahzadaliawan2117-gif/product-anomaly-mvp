import re
import unicodedata
from difflib import SequenceMatcher
from typing import Any, Dict, List, Optional, Tuple

from app.models.schemas import ProductMetadata


DOSAGE_TOKEN_RE = re.compile(
    r"(\d+(?:[.,]\d+)?)\s*(mg|g|mcg|ug|µg|ml|cl|l|%)",
    re.I,
)

GENERIC_PRODUCT_TOKENS = {
    "mg", "g", "mcg", "ug", "ml", "cl", "l",
    "tablet", "tablets", "comprime", "comprimes",
    "capsule", "capsules", "gelule", "gelules",
    "boite", "box", "pack", "oral", "dose",
}


def norm(value: Optional[str]) -> str:
    if not value:
        return ""
    value = (
        unicodedata.normalize("NFKD", str(value))
        .encode("ascii", "ignore")
        .decode()
        .lower()
    )
    return re.sub(r"[^a-z0-9%]+", " ", value).strip()


def tokens(value: Optional[str]) -> List[str]:
    return [x for x in norm(value).split() if len(x) > 1]


def _token_close(a: str, b: str) -> bool:
    if a == b:
        return True
    if min(len(a), len(b)) < 4:
        return False
    return SequenceMatcher(None, a, b).ratio() >= 0.84


def fuzzy(expected: Optional[str], text: Optional[str]):
    expected_norm = norm(expected)
    text_norm = norm(text)

    if not expected_norm:
        return None
    if not text_norm:
        return 0.0
    if expected_norm in text_norm:
        return 1.0

    expected_tokens = tokens(expected_norm)
    visible_tokens = tokens(text_norm)

    if not expected_tokens:
        return 0.0

    hits = 0.0
    for token in expected_tokens:
        if token in visible_tokens:
            hits += 1.0
        elif any(_token_close(token, candidate) for candidate in visible_tokens):
            hits += 0.75

    return min(1.0, hits / len(expected_tokens))


def exact_visible(expected: Optional[str], text: str) -> bool:
    expected_norm = norm(expected)
    text_norm = norm(text)

    if not expected_norm or not text_norm:
        return False
    if expected_norm in text_norm:
        return True

    return all(
        any(_token_close(x, y) for y in tokens(text_norm))
        for x in tokens(expected_norm)
    )


def dosage_value(value: Optional[str]) -> Optional[Tuple[float, str]]:
    if not value:
        return None

    m = DOSAGE_TOKEN_RE.search(str(value))
    if not m:
        return None

    number = float(m.group(1).replace(",", "."))
    unit = m.group(2).lower().replace("µg", "ug")

    if number <= 0:
        return None

    if unit == "g":
        return round(number * 1000, 4), "mg"
    if unit in {"mcg", "ug"}:
        return round(number / 1000, 4), "mg"
    if unit == "cl":
        return round(number * 10, 4), "ml"
    if unit == "l":
        return round(number * 1000, 4), "ml"

    return round(number, 4), unit


def dosage_family(value: Optional[Tuple[float, str]]) -> Optional[str]:
    if not value:
        return None
    if value[1] == "mg":
        return "mass"
    if value[1] == "ml":
        return "volume"
    if value[1] == "%":
        return "percent"
    return value[1]


def _expected_dosage(meta: ProductMetadata) -> Optional[Tuple[float, str]]:
    for value in (
        meta.dosage,
        meta.strength,
        meta.variant,
        meta.name,
        meta.packaging,
    ):
        parsed = dosage_value(value)
        if parsed:
            return parsed
    return None


def _core_name_tokens(name: Optional[str]) -> List[str]:
    if not name:
        return []

    cleaned = DOSAGE_TOKEN_RE.sub(" ", str(name))
    return [
        token
        for token in tokens(cleaned)
        if token not in GENERIC_PRODUCT_TOKENS
        and not token.isdigit()
    ]


def _core_product_score(name: Optional[str], text: str) -> Optional[float]:
    expected = _core_name_tokens(name)
    if not expected:
        return None

    visible = tokens(text)
    if not visible:
        return 0.0

    hits = 0.0
    for token in expected:
        if token in visible:
            hits += 1.0
        elif any(_token_close(token, candidate) for candidate in visible):
            hits += 0.75

    return min(1.0, hits / len(expected))


def infer_category(text: str) -> Optional[str]:
    visible = set(tokens(text))

    shampoo_strong = {
        "shampoo", "conditioner", "pantene", "dandruff",
    }
    shampoo_support = {
        "hair", "scalp", "silky", "aloe", "nutrients",
    }

    if visible & shampoo_strong or len(visible & shampoo_support) >= 2:
        return "Shampoo"

    medicine_strong = {
        "paracetamol", "ibuprofen", "doliprane", "maalox",
        "antacid", "tablet", "tablets", "capsule", "capsules",
        "comprime", "comprimes", "gelule", "gelules",
        "pharma", "medicine",
    }

    if visible & medicine_strong:
        return "Medicament"

    return None


def _candidate_values(ocr: Dict[str, Any]) -> List[Tuple[Tuple[float, str], str]]:
    raw_values = []

    if ocr.get("dosage"):
        raw_values.append(str(ocr["dosage"]))

    for value in ocr.get("dosage_candidates") or []:
        value = str(value)
        if value not in raw_values:
            raw_values.append(value)

    out = []
    seen = set()

    for raw in raw_values:
        parsed = dosage_value(raw)
        if parsed and parsed not in seen:
            seen.add(parsed)
            out.append((parsed, raw))

    return out


def _select_detected_dosage(
    ocr: Dict[str, Any],
    expected: Optional[Tuple[float, str]],
) -> Tuple[Optional[Tuple[float, str]], Optional[str]]:
    # Never compare a dosage that the OCR ensemble itself considers unreliable.
    if not ocr.get("dosage_reliable", bool(ocr.get("dosage"))):
        return None, None

    candidates = _candidate_values(ocr)
    if not candidates:
        return None, None

    if expected:
        family = dosage_family(expected)
        candidates = [
            pair
            for pair in candidates
            if dosage_family(pair[0]) == family
        ]

    if not candidates:
        return None, None

    votes = ocr.get("dosage_candidate_votes") or {}
    scores = ocr.get("dosage_candidate_scores") or {}

    def rank(pair):
        parsed, raw = pair
        return (
            int(votes.get(raw, 0)),
            float(scores.get(raw, 0.0)),
        )

    parsed, raw = max(candidates, key=rank)
    return parsed, raw


def match_product(meta: ProductMetadata, ocr: Dict[str, Any]) -> Dict[str, Any]:
    text = str(ocr.get("text", ""))

    fields = {}
    for key in ("name", "brand", "laboratory", "form", "packaging", "variant"):
        value = getattr(meta, key, None)
        if value:
            fields[key] = fuzzy(value, text)

    core_name_score = _core_product_score(meta.name, text)
    expected_dosage = _expected_dosage(meta)
    detected_dosage, detected_dosage_raw = _select_detected_dosage(
        ocr, expected_dosage
    )

    dosage_match = None
    if expected_dosage and detected_dosage:
        dosage_match = 1.0 if expected_dosage == detected_dosage else 0.0

    detected_category = infer_category(text)
    category_match = None

    if meta.category and detected_category:
        category_match = fuzzy(meta.category, detected_category)

    ocr_reliable = bool(
        ocr.get(
            "ocr_reliable",
            ocr.get("confidence", 0) >= 50 and len(tokens(text)) >= 3,
        )
    )

    brand_score = fields.get("brand")

    # Core family evidence deliberately ignores dosage/form words.
    same_product_family = (
        core_name_score is None
        or core_name_score >= 0.55
        or (
            brand_score is not None
            and brand_score >= 0.70
            and category_match is not None
            and category_match >= 0.70
        )
    )

    status = None
    reason = None

    # Category mismatch is strong only if both category signals exist.
    if category_match is not None and category_match < 0.50 and ocr_reliable:
        status = "WRONG_CATEGORY"
        reason = (
            f"Detected category '{detected_category}' conflicts with "
            f"expected category '{meta.category}'."
        )

    # Same product family + reliably different dosage is a variant mismatch.
    elif (
        dosage_match == 0.0
        and same_product_family
        and ocr.get("dosage_reliable", False)
    ):
        status = "WRONG_VARIANT"
        expected_display = (
            meta.dosage
            or meta.strength
            or f"{expected_dosage[0]:g} {expected_dosage[1]}"
        )
        reason = (
            f"Visible dosage/variant '{detected_dosage_raw}' conflicts with "
            f"expected dosage '{expected_display}'."
        )

    elif (
        brand_score is not None
        and brand_score < 0.30
        and same_product_family
        and ocr_reliable
    ):
        status = "WRONG_BRAND"
        reason = "Visible brand text conflicts with the expected brand."

    # Do not call WRONG_PRODUCT merely because tiny/unreadable packaging text
    # failed OCR. Require reliable OCR and strong identity contradiction.
    elif (
        core_name_score is not None
        and core_name_score < 0.20
        and ocr_reliable
    ):
        status = "WRONG_PRODUCT"
        reason = "Visible product identity strongly conflicts with expected metadata."

    elif (
        fields.get("variant") is not None
        and fields["variant"] < 0.30
        and same_product_family
        and ocr_reliable
    ):
        status = "WRONG_VARIANT"
        reason = "Visible variant text conflicts with expected metadata."

    # Weighted score from evidence that is actually available.
    evidence = []

    if core_name_score is not None:
        evidence.append((core_name_score, 0.42))
    if brand_score is not None:
        evidence.append((brand_score, 0.18))
    if fields.get("laboratory") is not None:
        evidence.append((fields["laboratory"], 0.07))
    if fields.get("form") is not None:
        evidence.append((fields["form"], 0.07))
    if fields.get("packaging") is not None:
        evidence.append((fields["packaging"], 0.06))
    if fields.get("variant") is not None:
        evidence.append((fields["variant"], 0.06))
    if dosage_match is not None:
        evidence.append((dosage_match, 0.30))
    if category_match is not None:
        evidence.append((category_match, 0.12))

    if evidence:
        score = 100 * sum(v * w for v, w in evidence) / sum(
            w for _, w in evidence
        )
    else:
        score = 50.0

    # Uncertain OCR should lower confidence, not create a false mismatch.
    if not ocr_reliable:
        score = max(45.0, min(score, 65.0))

    verification_incomplete = bool(
        expected_dosage
        and detected_dosage is None
    )

    detected_brand = (
        meta.brand
        if exact_visible(meta.brand, text)
        else None
    )

    detected_name = (
        meta.name
        if core_name_score is not None and core_name_score >= 0.70
        else None
    )

    detected_form = (
        meta.form
        if exact_visible(meta.form, text)
        else None
    )

    return {
        "product_match": round(score, 1),
        "mismatch_status": status,
        "reason": reason,
        "field_scores": {
            **{k: round(v * 100, 1) for k, v in fields.items()},
            "core_name": (
                None if core_name_score is None
                else round(core_name_score * 100, 1)
            ),
        },
        "expected_dosage": (
            None
            if expected_dosage is None
            else f"{expected_dosage[0]:g} {expected_dosage[1]}"
        ),
        "dosage_match": (
            None if dosage_match is None else bool(dosage_match)
        ),
        "dosage_reliable": bool(ocr.get("dosage_reliable", False)),
        "verification_incomplete": verification_incomplete,
        "detected_category": detected_category,
        "evidence_reliable": ocr_reliable,
        "detected": {
            "name": detected_name,
            "brand": detected_brand,
            "category": detected_category,
            "dosage": detected_dosage_raw,
            "form": detected_form,
            "quantity": ocr.get("quantity"),
        },
    }
